<?php
$image = 'result.png';

$stego_image = imagecreatefrompng($image);
$pesan = '';

$count = 0;
$col = 0;
$row = 0;

list($width, $height, $type, $attr) = getimagesize($image);

for ($x = 0; $x < ($width*$height); $x++) {
    if($col === $width+1){
        $row++;
        $col=0;
    }

    if($row===$height && $col===$width){
        die();
    }

    $rgb = imagecolorat($stego_image,$col,$row);
    $r = ($rgb >>16) & 0xFF; 
    $g = ($rgb >>8) & 0xFF; 
    $b = $rgb & 0xFF;
    $b = (string)$b; 
    //proses warna b jadi bit
    $panjang_b = strlen($b);
    $blue = "";
    while($panjang_b--){
        $blue = str_pad(decbin(ord($b[$panjang_b])),8,"0",STR_PAD_LEFT).$blue;
    }

    $pesan .= $blue[strlen($blue) - 1]; 

    $count++;

    if ($count == 8) { //jika panjang pesan sudah 8 bit
        //bit $pesan to string
        $array_pesan = explode("\r\n", chunk_split(substr($pesan, -8), 8));
        $baru_pesan = '';
        for ($n = 0; $n < count($array_pesan) - 1; $n++) {
            $baru_pesan .= chr(base_convert($array_pesan[$n], 2, 10));
        }

        if ($baru_pesan === '=') { //jika ketemu batas yaitu =
            echo ('selesai dekrip<br>');
            $array_pesan = explode("\r\n", chunk_split(substr($pesan,0,-8), 8));
            $baru_pesan = '';
            for ($n = 0; $n < count($array_pesan) - 1; $n++) {
                $baru_pesan .= chr(base_convert($array_pesan[$n], 2, 10));
            }
            echo ('Hasil Dekrip: ');
            echo $baru_pesan;
            die;
        }
        $count = 0;
    }
  $col++;
}