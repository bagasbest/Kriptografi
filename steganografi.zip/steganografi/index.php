<?php 

$pesan = "saya adalah seorang mahasiswa di itera, salam kenal";
$image = "start.jpg";

$pesan .= '=';//untuk batas saat dekrip

echo "panjang pesan = ".strlen($pesan)."<br>"; //panjang pesan
//proses pesan jadi bit
$panjang = strlen($pesan);
$hasil_bit_pesan = "";
while($panjang--){
    $hasil_bit_pesan = str_pad(decbin(ord($pesan[$panjang])),8,"0",STR_PAD_LEFT).$hasil_bit_pesan;
}
//akhir pesan jadi bit

$panjang_bit_pesan = strlen($hasil_bit_pesan); //panjang bit pesan
echo "panjang bit pesan = ".$panjang_bit_pesan."<br>";

//identifikasi gambar dan ukuran
$cover_image = imagecreatefromjpeg($image);
list($width, $height, $type, $attr) = getimagesize($image);
$size_image = $width*$height;//besar gambar
echo "ukuran gambar = ".$size_image."<br>";
//akhir identifikasi gambar dan ukuran

//jika pesan > image tidak bisa
if($panjang_bit_pesan > $size_image){
    echo "maaf pesan anda terlalu panjang";
    die(); //sistem berhenti
}

$col = 0;
$row = 0;
for($i=0;$i<$panjang_bit_pesan;$i++){
    if($col == $width+1){
        $col = 0;
        $row ++;
    }
    if($row == $height && $col==$width){
        die();
    }
    //proses mengambil rgb dari setiap pixel
    $rgb = imagecolorat($cover_image,$col,$row);
    $r = ($rgb >> 16) & 0xFF;
    $g = ($rgb >> 8) & 0xFF;
    $b = $rgb & 0xFF;
    $b = (string)$b; //$b jadi string
    //akhir proses mengambil rgb dari setiap pixel

    //proses warna b jadi bit
    $panjang_b = strlen($b);
    $hasil_bit_b = "";
    while($panjang_b--){
        $hasil_bit_b = str_pad(decbin(ord($b[$panjang_b])),8,"0",STR_PAD_LEFT).$hasil_bit_b;
    }
    //akhir warna b jadi bit

    $hasil_bit_b[strlen($hasil_bit_b)-1] = $hasil_bit_pesan[$i];//penyisipan bit pesan pada lsb

    $array_hasil_bit_b = explode("\r\n", chunk_split($hasil_bit_b, 8));
    $baru_hasil_bit_b = '';
    for ($n = 0; $n < count($array_hasil_bit_b) - 1; $n++) {
        $baru_hasil_bit_b .= chr(base_convert($array_hasil_bit_b[$n], 2, 10));
    }

    $rgb_stego = imagecolorallocate($cover_image,$r,$g,$baru_hasil_bit_b); 
    imagesetpixel($cover_image,$col,$row,$rgb_stego);//mengubah pixel menjadi hasil penyisipan bit pesan
    $col++;
}

//simpan stego image otomatis
imagepng($cover_image,'result.png');
echo('done: ' . 'result.png');

imagedestroy($cover_image);
